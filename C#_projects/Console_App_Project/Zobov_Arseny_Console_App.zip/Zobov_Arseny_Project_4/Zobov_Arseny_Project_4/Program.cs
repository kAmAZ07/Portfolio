﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using Player_Library;
using Spectre.Console;
using System;
using System.Linq;
using System.Threading;

/// <summary>
/// Основной класс программы
/// </summary>
public class Program
{
    public static MusicPlayer organizer;
    public static string filepath;

    /// <summary>
    /// Точка входа в программу. Отображает главное меню и обрабатывает выбор пользователя.
    /// </summary>
    public static void Main()
    {
        while (true)
        {
            string choice = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите действие:")
                    .AddChoices(
                    [
                    "Загрузить треки (.txt/.csv)",
                    "Вывести треки",
                    "Воспроизвести треки",
                    "Взаимодействие с ресурсом musicbrainz",
                    "Действия с загруженным файлом (или созданным) с треками",
                    "Загрузить треки из директории",
                    "Выход"
                    ])
            );

            switch (choice)
            {
                case "Загрузить треки (.txt/.csv)":
                    InputFunc();
                    break;
                case "Загрузить треки из директории":
                    AnsiConsole.Markup("[yellow]Введите путь к папке для сканирования:[/]\n> ");
                    string folderPath = Console.ReadLine().Trim('\"');

                    ScanFolder(folderPath).GetAwaiter().GetResult();
                    break;
                case "Вывести треки":
                    OutputTracksFunc();
                    break;
                case "Действия с загруженным файлом (или созданным) с треками":
                    FileOperationsFunc();
                    break;

                case "Воспроизвести треки":
                    PlayTrackFunc();
                    break;
                case "Взаимодействие с ресурсом musicbrainz":
                    MusicBrainzServiceFunc();
                    break;
                case "Выход":
                    return;
            }
        }
    }

    /// <summary>
    /// Обрабатывает загрузку треков из файла (.txt или .csv).
    /// </summary>
    public static void InputFunc()
    {
        try
        {
            Console.WriteLine("Введите путь к файлу каталога треков:");
            string filePath = Console.ReadLine();
            if (string.IsNullOrEmpty(filePath))
            {
                AnsiConsole.Markup($"[red]Ничего не введено, попробуйте ещё раз[/]");
                Thread.Sleep(800);
                return;
            }

            AnsiConsole.Status()
                .AutoRefresh(true)
                .Spinner(Spinner.Known.Star)
                .SpinnerStyle(Style.Parse("green bold"))
                .Start("Загрузка...", ctx =>
                {
                    for (int i = 0; i <= 100; i++)
                    {
                        _ = ctx.Status($"[yellow]Loading... {i}%[/]");
                        Thread.Sleep(10);
                    }

                    _ = ctx.Status("[green]Done![/]");
                    Thread.Sleep(500);

                    organizer = new(filePath);
                    filepath = filePath;
                });
        }
        catch (Exception e)
        {
            AnsiConsole.Markup($"[red]Ошибка: {e.Message}[/]");
            return;
        }
    }

    /// <summary>
    /// Обрабатывает действия с загруженным файлом треков (или созданным).
    /// </summary>
    public static void FileOperationsFunc()
    {
        string choice = AnsiConsole.Prompt(
               new SelectionPrompt<string>()
                   .Title("Выберите способ вывода:")
                   .AddChoices(
                   [
                    "Экспорт треков в csv",
                    "Добавить трек (вручную)",
                    "Редактировать трек",
                    "Удалить трек",
                    "Вернуться к меню"
                   ])
           );

        switch (choice)
        {
            case "Добавить трек (вручную)":
                AddTrackFunc();
                break;
            case "Экспорт треков в csv":
                ExportToCsv();
                break;
            case "Редактировать трек":
                EditTrackFunc();
                break;
            case "Удалить трек":
                RemoveTrackFunc();
                break;
            case "Выход":
                return;
        }
    }

    /// <summary>
    /// Обрабатывает взаимодействие с API MusicBrainz.
    /// </summary>
    public static void MusicBrainzServiceFunc()
    {
        string choice = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите способ вывода:")
                    .AddChoices(
                    [
                    "Обновить данные треков с помощью MusicBrainz",
                    "Получить данные по MBID",
                    "Получить информацию об исполнителе",
                    "Получить информацию об альбоме",
                    "Вернуться к меню"
                    ])
            );

        switch (choice)
        {
            case "Обновить данные треков с помощью MusicBrainz":
                UpdateWithMusicBrainzFunc().GetAwaiter().GetResult();
                break;

            case "Получить данные по MBID":
                MBIDFunc();
                break;
            case "Получить информацию об исполнителе":
                ArtistInfoFunc();
                break;
            case "Получить информацию об альбоме":
                AlbumInfoFunc();
                break;
            case "Выход":
                return;
        }
    }

    /// <summary>
    /// Обрабатывает вывод треков на экран.
    /// </summary>
    public static void OutputTracksFunc()
    {
        string choice = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите способ вывода:")
                    .AddChoices(
                    [
                    "Базовый",
                    "Таблица",
                    "Дерево",
                    "Вернуться к меню"
                    ])
            );

        switch (choice)
        {
            case "Базовый":
                BaseOutput();
                break;

            case "Таблица":
                TableShowFunc();
                break;
            case "Дерево":
                TreeFunc();
                break;

            case "Выход":
                return;
        }
    }

    /// <summary>
    /// Выводит треки в формате базовой задачи
    /// </summary>
    public static void BaseOutput()
    {
        if (MusicPlayer.GetTracks().Count == 0)
        {
            AnsiConsole.Markup("[yellow]Каталог треков пуст.[/]\n");
            return;
        }
        Console.WriteLine("Каталог треков:");
        Console.WriteLine(new string('-', 40));
        foreach (Track track in MusicPlayer.GetTracks())
        {
            Console.WriteLine(track);
            Console.WriteLine(new string('-', 40));
        }
    }

    /// <summary>
    /// Красиво выводит треки в виде таблицы с возможностью фильтрации и сортировки.
    /// </summary>
    public static void TableShowFunc()
    {
        if (MusicPlayer.GetTracks().Count == 0)
        {
            AnsiConsole.Markup("[yellow]Каталог треков пуст.[/]\n");
            return;
        }

        List<Track> allTracks = MusicPlayer.GetTracks();
        List<Track> filteredAndSortedTracks = new(allTracks);
        List<TrackOperations> operations = [];

        string filename = filepath.Substring(Math.Max(filepath.LastIndexOf('\\', filepath.LastIndexOf('.')), filepath.LastIndexOf('/', filepath.LastIndexOf('.'))) + 1, filepath.LastIndexOf('.') - Math.Max(filepath.LastIndexOf('\\', filepath.LastIndexOf('.')), filepath.LastIndexOf('/', filepath.LastIndexOf('.'))) - 1);
        int pageSize = 10;
        int scrollPosition = 0;
        bool isRunning = true;

        while (isRunning)
        {
            AnsiConsole.Clear();
            AnsiConsole.Write(
                new Rule($"[bold underline yellow]Файл: {filename}[/]")
                    .RuleStyle(Style.Parse("yellow"))
                    .Centered()
            );
            AnsiConsole.WriteLine();

            filteredAndSortedTracks = new(allTracks);
            foreach (TrackOperations operation in operations)
            {
                operation.Apply(filteredAndSortedTracks);
            }

            Table table = new Table()
                .Border(TableBorder.Minimal)
                .AddColumn(new TableColumn("[bold red]Название[/]"))
                .AddColumn(new TableColumn("[bold green]Исполнитель[/]"))
                .AddColumn(new TableColumn("[bold blue]Альбом[/]"))
                .AddColumn(new TableColumn("[bold magenta]Год[/]"))
                .AddColumn(new TableColumn("[bold cyan]Жанр[/]"));

            List<Track> visibleTracks = filteredAndSortedTracks
                .Skip(scrollPosition)
                .Take(pageSize)
                .ToList();

            foreach (Track track in visibleTracks)
            {
                _ = table.AddRow(track.Title, track.Artist, track.Album, track.Year.ToString(), track.Genre);
            }

            AnsiConsole.Live(table).Start(ctx =>
            {
                ctx.UpdateTarget(table);
                int totalPages = (int)Math.Ceiling(filteredAndSortedTracks.Count / (double)pageSize);
                int currentPage = (scrollPosition / pageSize) + 1;
                AnsiConsole.MarkupLine($"[grey]Страница {currentPage} из {totalPages}[/]");
            });

            if (operations.Count > 0)
            {
                AnsiConsole.MarkupLine("[bold underline green]Текущие операции:[/]");
                for (int i = 0; i < operations.Count; i++)
                {
                    AnsiConsole.MarkupLine($"{i + 1}. {operations[i]}");
                }
            }

            AnsiConsole.MarkupLine("[grey]Используйте стрелки для выбора действия:[/]");
            string action = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Tool Bar")
                    .AddChoices(["Добавить операцию", "Удалить операцию", "Прокрутить вверх", "Прокрутить вниз", "Выйти"])
            );

            switch (action)
            {
                case "Добавить операцию":
                    AdditiveFunctions.AddOperation(operations);
                    scrollPosition = 0;
                    break;
                case "Удалить операцию":
                    AdditiveFunctions.RemoveOperation(operations);
                    scrollPosition = 0;
                    break;
                case "Прокрутить вверх":
                    if (scrollPosition > 0)
                    {
                        scrollPosition -= pageSize;
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[yellow]Вы уже в начале списка.[/]");
                    }
                    break;
                case "Прокрутить вниз":
                    if (scrollPosition + pageSize < filteredAndSortedTracks.Count)
                    {
                        scrollPosition += pageSize;
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[yellow]Вы уже в конце списка.[/]");
                    }
                    break;
                case "Выйти":
                    isRunning = false;
                    break;
            }
        }
    }

    /// <summary>
    /// Выводит треки в виде дерева, сгруппированного по исполнителям и альбомам.
    /// </summary>
    public static void TreeFunc()
    {
        if (MusicPlayer.GetTracks().Count == 0)
        {
            AnsiConsole.Markup("[yellow]Каталог треков пуст.[/]\n");
            return;
        }

        List<Track> tracks = MusicPlayer.GetTracks();

        Dictionary<string, Dictionary<string, List<Track>>> groupedTracks = tracks
            .GroupBy(track => track.Artist)
            .ToDictionary(
                artistGroup => artistGroup.Key,
                artistGroup => artistGroup
                    .GroupBy(track => track.Album)
                    .ToDictionary(
                        albumGroup => albumGroup.Key,
                        albumGroup => albumGroup.ToList()
                    )
            );

        Tree tree = new Tree("[bold yellow]Каталог треков[/]")
            .Guide(TreeGuide.DoubleLine);
        foreach (string artist in groupedTracks.Keys)
        {
            TreeNode artistNode = tree.AddNode($"[bold green]{artist}[/]");
            foreach (string album in groupedTracks[artist].Keys)
            {
                TreeNode albumNode = artistNode.AddNode($"[bold blue]{album}[/]");
                foreach (Track track in groupedTracks[artist][album])
                {
                    _ = albumNode.AddNode($"[cyan]{track.Title} ({track.Year}, {track.Genre})[/]");
                }
            }
        }
        AnsiConsole.Render(tree);
    }


    /// <summary>
    /// Обрабатывает воспроизведение треков
    /// </summary>

    // AI_INSPIRATION_2
    public static void PlayTrackFunc()
    {
        while (true)
        {
            List<Track> tracks = MusicPlayer.GetTracks();
            List<Track> validTracks = tracks.Where(track => !string.IsNullOrEmpty(track.FilePath)).ToList();

            if (validTracks.Count == 0)
            {
                AnsiConsole.Markup("[yellow]Каталог треков пуст или ни один трек не содержит пути к файлу.[/]\n");
                return;
            }

            var trackChoices = validTracks.Select((track, index) =>
                new { Index = index, Track = track })
                .ToList();

            string selectedTrackIndex = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите трек для воспроизведения:")
                    .AddChoices(trackChoices.Select(t => $"{t.Index + 1}. {t.Track.Title} - {t.Track.Artist}"))
            );

            int selectedIndex = int.Parse(selectedTrackIndex.Split('.')[0]) - 1;
            Track selectedTrack = trackChoices[selectedIndex].Track;

            AnsiConsole.MarkupLine($"\n[bold green]Воспроизводится:[/] {selectedTrack.Title} - {selectedTrack.Artist}\n");
            AnsiConsole.MarkupLine("[grey]F - промотка вперёд, B - промотка назад, Esc - остановка, Space - пауза/воспроизведение[/]");

            TrackPlayer.Play(selectedTrack.FilePath);
            int trackDuration = TrackPlayer.GetTotalDuration();
            bool isPlaying = true;
            bool isPaused = false;

            AnsiConsole.Progress()
                .AutoClear(false)
                .Columns(
                [
                    new TaskDescriptionColumn(),
                    new ProgressBarColumn(),
                    new RemainingTimeColumn()
                ])
                .Start(ctx =>
                {
                    ProgressTask task = ctx.AddTask($"[cyan]{selectedTrack.Title} *Play*[/]", autoStart: false);
                    task.MaxValue = trackDuration;

                    while (isPlaying && TrackPlayer.GetCurrentPosition() < trackDuration)
                    {
                        int currentPosition = TrackPlayer.GetCurrentPosition();
                        task.Value = currentPosition;

                        string currentTime = AdditiveFunctions.FormatTime(currentPosition);
                        string totalTime = AdditiveFunctions.FormatTime(trackDuration);
                        task.Description = isPaused
                            ? $"[cyan]{selectedTrack.Title} *Pause* ({currentTime} / {totalTime})[/]"
                            : $"[cyan]{selectedTrack.Title} *Play* ({currentTime} / {totalTime})[/]";

                        Thread.Sleep(150);

                        if (Console.KeyAvailable)
                        {
                            ConsoleKey key = Console.ReadKey(intercept: true).Key;
                            switch (key)
                            {
                                case ConsoleKey.Escape:
                                    isPlaying = false;
                                    TrackPlayer.Stop();
                                    break;

                                case ConsoleKey.Spacebar:
                                    if (isPaused)
                                    {
                                        TrackPlayer.Resume();
                                        isPaused = false;
                                    }
                                    else
                                    {
                                        TrackPlayer.Pause();
                                        isPaused = true;
                                    }
                                    break;

                                case ConsoleKey.F:
                                    int newPositionForward = Math.Min(TrackPlayer.GetCurrentPosition() + 10, trackDuration);
                                    TrackPlayer.Rewind(newPositionForward);
                                    break;

                                case ConsoleKey.B:
                                    int newPositionBackward = Math.Max(TrackPlayer.GetCurrentPosition() - 10, 0);
                                    TrackPlayer.Rewind(newPositionBackward);
                                    break;
                            }
                        }
                    }

                    if (!isPlaying)
                    {
                        AnsiConsole.MarkupLine("\n[yellow]Воспроизведение остановлено пользователем[/]");
                    }
                    else
                    {
                        AnsiConsole.MarkupLine($"[green]Трек {selectedTrack.Title} завершился[/]");
                    }
                });

            string continuePlayback = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Хотите выбрать другой трек?")
                    .AddChoices(["Да", "Нет"])
            );

            if (continuePlayback == "Нет")
            {
                break;
            }
        }
    }

    /// <summary>
    /// Обновляет данные треков с использованием API MusicBrainz.
    /// </summary>

    // AI_INSPIRATION_1
    public static async Task UpdateWithMusicBrainzFunc()
    {
        if (MusicPlayer.GetTracks().Count == 0)
        {
            AnsiConsole.Markup("[yellow]Каталог треков пуст.[/]\n");
            return;
        }

        List<Track> tracks = MusicPlayer.GetTracks();
        var trackChoices = tracks.Select((track, index) =>
            new { Index = index, Track = track })
            .ToList();

        string selectedTrackIndex = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
                .Title("Выберите трек для обновления данных:")
                .AddChoices(trackChoices.Select(t => $"{t.Index + 1}. {t.Track.Title} - {t.Track.Artist}"))
        );

        int selectedIndex = int.Parse(selectedTrackIndex.Split('.')[0]) - 1;
        Track selectedTrack = trackChoices[selectedIndex].Track;

        string correctedTitle = MusicBrainzService.FindBestMatch(selectedTrack.Title, tracks.Select(t => t.Title));
        string correctedArtist = MusicBrainzService.FindBestMatch(selectedTrack.Artist, tracks.Select(t => t.Artist));

        AnsiConsole.MarkupLine($"[yellow]Предлагаемые исправления:[/]");
        AnsiConsole.MarkupLine($"Название: {correctedTitle}");
        AnsiConsole.MarkupLine($"Исполнитель: {correctedArtist}");

        bool confirm = AnsiConsole.Confirm("Использовать эти данные?");
        if (!confirm)
        {
            AnsiConsole.MarkupLine("[yellow]Операция отменена пользователем.[/]");
            return;
        }

        List<Track> updatedTracks = await MusicBrainzService.UpdateInfo(correctedTitle, correctedArtist);

        if (updatedTracks.Count == 0)
        {
            AnsiConsole.MarkupLine("[red]Трек не найден в базе данных MusicBrainz.[/]");
            return;
        }

        var trackOptions = updatedTracks.Select((track, index) =>
            new { Index = index, Track = track })
            .ToList();

        string selectedOptionIndex = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
                .Title("Выберите наиболее подходящий трек:")
                .AddChoices(trackOptions.Select(t => $"{t.Index + 1}. {t.Track.Title} - {t.Track.Artist} - {t.Track.Album}"))
        );

        int selectedOption = int.Parse(selectedOptionIndex.Split('.')[0]) - 1;
        Track bestMatch = trackOptions[selectedOption].Track;

        selectedTrack.Album = bestMatch.Album;
        selectedTrack.Year = bestMatch.Year;
        selectedTrack.Genre = bestMatch.Genre;

        AnsiConsole.MarkupLine($"[green]Данные успешно обновлены:[/]");
        AnsiConsole.MarkupLine($"Название: {selectedTrack.Title}");
        AnsiConsole.MarkupLine($"Исполнитель: {selectedTrack.Artist}");
        AnsiConsole.MarkupLine($"Альбом: {selectedTrack.Album}");
        AnsiConsole.MarkupLine($"Год выпуска: {selectedTrack.Year}");
        AnsiConsole.MarkupLine($"Жанр: {selectedTrack.Genre}");
    }

    /// <summary>
    /// Добавляет новый трек в список.
    /// </summary>
    public static void AddTrackFunc()
    {
        AnsiConsole.MarkupLine("[bold green]Добавление нового трека[/]");
        AnsiConsole.MarkupLine("[grey]Нажмите Esc в любой момент, чтобы прервать добавление.[/]\n");

        try
        {
            if (string.IsNullOrEmpty(filepath) || !File.Exists(filepath))
            {
                AnsiConsole.MarkupLine("[yellow]Файл с треками не загружен.[/]");
                bool createNewFile = AnsiConsole.Confirm("Хотите создать новый файл в папке MusicMaterials?");

                if (createNewFile)
                {
                    string loadingPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MusicMaterials");
                    _ = Directory.CreateDirectory(loadingPath);

                    string fileName = MusicPlayer.PromptInput("Введите имя нового файла (без расширения):", allowEmpty: false, defaultValue: "tracks");
                    filepath = Path.Combine(loadingPath, $"{fileName}.txt");

                    File.Create(filepath).Close();
                    AnsiConsole.MarkupLine($"[green]Файл успешно создан: {filepath}[/]");

                }
                else
                {
                    AnsiConsole.MarkupLine("[yellow]Операция отменена.[/]");
                    return;
                }
                organizer = new MusicPlayer(filepath);
            }

            string title = MusicPlayer.PromptInput("Введите новое название трека:", allowEmpty: false, "");
            string artist = MusicPlayer.PromptInput("Введите новое имя исполнителя:", allowEmpty: false, defaultValue: "");
            string album = MusicPlayer.PromptInput("Введите новое название альбома (если есть):", allowEmpty: true, defaultValue: "");
            int year = MusicPlayer.PromptYear("Введите новый год выпуска (например, 1999):", defaultValue: 0);
            string genre = MusicPlayer.PromptInput("Введите новый жанр трека (если есть):", allowEmpty: true, defaultValue: "");
            string filePath = MusicPlayer.PromptInput("Введите путь к MP3-файлу (оставьте пустым, если нет):", allowEmpty: true, defaultValue: "");

            Track newTrack = new(
                title: title,
                artist: artist,
                album: album,
                year: year,
                genre: genre,
                filePath: string.IsNullOrEmpty(filePath) ? string.Empty : filePath
            );

            MusicPlayer.AddTrack(newTrack, filepath);
            AnsiConsole.MarkupLine($"[green]Трек успешно добавлен:[/]\n{newTrack}");
        }
        catch (OperationCanceledException)
        {
            AnsiConsole.MarkupLine("\n[yellow]Добавление трека отменено пользователем.[/]");
        }
    }

    /// <summary>
    /// Редактирует существующий трек
    /// </summary>
    public static void EditTrackFunc()
    {
        List<Track> tracks = MusicPlayer.GetTracks();

        if (tracks.Count == 0)
        {
            AnsiConsole.Markup("[yellow]Каталог треков пуст.[/]\n");
            return;
        }

        var trackChoices = tracks.Select((track, index) =>
            new { Index = index, Track = track })
            .ToList();

        string selectedTrackIndex = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
                .Title("Выберите трек для редактирования:")
                .AddChoices(trackChoices.Select(t => $"{t.Index + 1}. {t.Track.Title} - {t.Track.Artist}"))
        );

        int selectedIndex = int.Parse(selectedTrackIndex.Split('.')[0]) - 1;
        Track selectedTrack = trackChoices[selectedIndex].Track;

        AnsiConsole.MarkupLine($"[bold green]Редактирование трека:[/] {selectedTrack.Title} - {selectedTrack.Artist}");

        selectedTrack.Title = MusicPlayer.PromptInput("Введите новое название трека:", allowEmpty: false, defaultValue: selectedTrack.Title);
        selectedTrack.Artist = MusicPlayer.PromptInput("Введите новое имя исполнителя:", allowEmpty: false, defaultValue: selectedTrack.Artist);
        selectedTrack.Album = MusicPlayer.PromptInput("Введите новое название альбома (если есть):", allowEmpty: true, defaultValue: selectedTrack.Album);
        selectedTrack.Year = MusicPlayer.PromptYear("Введите новый год выпуска (например, 1999):", defaultValue: selectedTrack.Year);
        selectedTrack.Genre = MusicPlayer.PromptInput("Введите новый жанр трека (если есть):", allowEmpty: true, defaultValue: selectedTrack.Genre);
        selectedTrack.FilePath = MusicPlayer.PromptInput("Введите новый путь к MP3-файлу (оставьте пустым, если нет):", allowEmpty: true, defaultValue: selectedTrack.FilePath);

        MusicPlayer.SaveTracksToFile(filepath);

        AnsiConsole.MarkupLine($"[green]Трек успешно отредактирован:[/]\n{selectedTrack}");
    }

    /// <summary>
    /// Удаляет трек
    /// </summary>
    public static void RemoveTrackFunc()
    {
        List<Track> tracks = MusicPlayer.GetTracks();

        if (tracks.Count == 0)
        {
            AnsiConsole.Markup("[yellow]Каталог треков пуст.[/]\n");
            return;
        }

        var trackChoices = tracks.Select((track, index) =>
            new { Index = index, Track = track })
            .ToList();

        string selectedTrackIndex = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
                .Title("Выберите трек для удаления:")
                .AddChoices(trackChoices.Select(t => $"{t.Index + 1}. {t.Track.Title} - {t.Track.Artist}"))
        );

        int selectedIndex = int.Parse(selectedTrackIndex.Split('.')[0]) - 1;
        Track selectedTrack = trackChoices[selectedIndex].Track;

        AnsiConsole.MarkupLine($"[bold red]Удаление трека:[/] {selectedTrack.Title} - {selectedTrack.Artist}");

        bool confirm = AnsiConsole.Confirm("Вы уверены, что хотите удалить этот трек?");
        if (confirm)
        {
            MusicPlayer.RemoveTrack(selectedIndex);

            MusicPlayer.SaveTracksToFile(filepath);

            AnsiConsole.MarkupLine($"[green]Трек успешно удален:[/]\n{selectedTrack}");
        }
        else
        {
            AnsiConsole.MarkupLine("[yellow]Удаление отменено пользователем.[/]");
        }
    }

    /// <summary>
    /// Получает информацию о треке по его MBID через API MusicBrainz.
    /// </summary>
    public static void MBIDFunc()
    {

        AnsiConsole.Markup("[yellow]Введите MBID трека:[/]\n> ");
        string mbid = Console.ReadLine();
        if (string.IsNullOrEmpty(mbid))
        {
            AnsiConsole.MarkupLine("[red]Некорректный MBID.[/]");
            return;
        }
        else
        {
            Track track = MusicBrainzService.GetInfoByMBID(mbid);
            if (track != null)
            {
                AnsiConsole.MarkupLine($"[green]Трек найден:[/]\n{track}");
            }
        }
    }

    /// <summary>
    /// Получает информацию об исполнителе через API MusicBrainz.
    /// </summary>
    public static void ArtistInfoFunc()
    {
        AnsiConsole.Markup("[yellow]Хотите найти исполнителя по имени или выбрать из файла с треками?[/]\n");
        string choice = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
                .Title("Выберите действие:")
                .AddChoices(["По имени", "Из файла"])
        );

        string artistName = null;
        string artistMbid = null;

        if (choice == "По имени")
        {
            AnsiConsole.Markup("[yellow]Введите название исполнителя:[/]\n> ");
            artistName = Console.ReadLine();

            List<ArtistListOfResults> searchResults = MusicBrainzService.SearchArtists(artistName);
            if (searchResults.Count == 0)
            {
                AnsiConsole.MarkupLine("[red]Исполнители не найдены.[/]");
                return;
            }

            ArtistListOfResults selectedArtist = AnsiConsole.Prompt(
                new SelectionPrompt<ArtistListOfResults>()
                    .Title("Выберите исполнителя:")
                    .AddChoices(searchResults)
            );
            artistMbid = selectedArtist.Id;
        }
        else if (choice == "Из файла")
        {
            List<Track> tracks = MusicPlayer.GetTracks();
            if (tracks.Count == 0)
            {
                AnsiConsole.MarkupLine("[yellow]Каталог треков пуст.[/]");
                return;
            }

            List<string> uniqueArtists = tracks.Select(t => t.Artist).Distinct().ToList();
            artistName = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите исполнителя:")
                    .AddChoices(uniqueArtists)
            );
            if (string.IsNullOrEmpty(artistName))
            {
                AnsiConsole.MarkupLine("[red]Не удалось выбрать исполнителя.[/]");
                return;
            }

            List<ArtistListOfResults> searchResults = MusicBrainzService.SearchArtists(artistName);
            if (searchResults.Count == 0)
            {
                AnsiConsole.MarkupLine("[red]Исполнитель не найден в MusicBrainz.[/]");
                return;
            }

            artistMbid = searchResults.First().Id;
        }

        ArtistInfo artistInfo = MusicBrainzService.GetArtistInfo(artistMbid);
        if (artistInfo != null)
        {
            AnsiConsole.MarkupLine($"[green]Информация об исполнителе:[/]\n{artistInfo}");
        }
    }

    /// <summary>
    /// Получает информацию об альбоме через API MusicBrainz.
    /// </summary>
    public static void AlbumInfoFunc()
    {
        AnsiConsole.Markup("[yellow]Хотите найти альбом по имени или выбрать из файла с треками?[/]\n");
        string choice = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
                .Title("Выберите действие:")
                .AddChoices(["По имени", "Из файла"])
        );

        string albumName = null;
        string albumMbid = null;

        if (choice == "По имени")
        {
            AnsiConsole.Markup("[yellow]Введите название альбома:[/]\n> ");
            albumName = Console.ReadLine();

            List<AlbumListOfResults> searchResults = MusicBrainzService.SearchAlbums(albumName);
            if (searchResults.Count == 0)
            {
                AnsiConsole.MarkupLine("[red]Альбомы не найдены.[/]");
                return;
            }
            AlbumListOfResults selectedAlbum = AnsiConsole.Prompt(
                new SelectionPrompt<AlbumListOfResults>()
                    .Title("Выберите альбом:")
                    .AddChoices(searchResults)
            );
            albumMbid = selectedAlbum.Id;
        }
        else if (choice == "Из файла")
        {
            List<Track> tracks = MusicPlayer.GetTracks();
            if (tracks.Count == 0)
            {
                AnsiConsole.MarkupLine("[yellow]Каталог треков пуст.[/]");
                return;
            }

            List<string> uniqueAlbums = tracks.Select(t => t.Album).Distinct().ToList();
            albumName = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите альбом:")
                    .AddChoices(uniqueAlbums)
            );
            if (string.IsNullOrEmpty(albumName))
            {
                AnsiConsole.MarkupLine("[red]Не удалось выбрать альбом.[/]");
                return;
            }
            List<AlbumListOfResults> searchResults = MusicBrainzService.SearchAlbums(albumName);
            if (searchResults.Count == 0)
            {
                AnsiConsole.MarkupLine("[red]Альбом не найден в MusicBrainz.[/]");
                return;
            }

            albumMbid = searchResults.First().Id;
        }
        AlbumInfo albumInfo = MusicBrainzService.GetAlbumInfo(albumMbid);
        if (albumInfo != null)
        {
            AnsiConsole.MarkupLine($"[green]Информация об альбоме:[/]\n{albumInfo}");
        }
    }

    /// <summary>
    /// Экспортирует треки в CSV-файл.
    /// </summary>
    public static void ExportToCsv()
    {
        try
        {
            string firstPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\MusicMaterials"));
            _ = Directory.CreateDirectory(firstPath);


            string fileName = MusicPlayer.PromptInput("Введите имя нового файла (без расширения):", allowEmpty: false, defaultValue: "Tracks");
            string loadingPath = Path.Combine(firstPath, $"{fileName}.csv");
            if (File.Exists(loadingPath))
            {
                bool overwrite = AnsiConsole.Confirm($"Файл уже существует: {loadingPath}. Перезаписать его?");
                if (!overwrite)
                {
                    AnsiConsole.MarkupLine("[yellow]Операция отменена пользователем.[/]");
                    return;
                }
            }

            File.Create(loadingPath).Close();
            AnsiConsole.MarkupLine($"[grey]Файл успешно создан: {loadingPath}[/]");

            List<Track> lines = MusicPlayer.GetTracks();
            using StreamWriter writer = new(loadingPath, true);
            writer.WriteLine("Title,Artist,Album,Year,Genre,FilePath");
            foreach (Track track in lines)
            {
                writer.WriteLine($"{track.Title},{track.Artist},{track.Album},{track.Year},{track.Genre},{track.FilePath}");
            }
            AnsiConsole.MarkupLine($"[bold green]Экспортировано {lines.Count} треков в файл: {fileName}.csv[/]");
        }
        catch (Exception ex)
        {
            AnsiConsole.MarkupLine($"\n[bold red]Возникла ошибка: {ex}[/]");
        }

    }

    /// <summary>
    /// Сканирует указанную папку для добавления треков в список.
    /// </summary>
    /// <param name="folderPath">Путь к папке для сканирования.</param>
    public static async Task ScanFolder(string folderPath)
    {
        if (!Directory.Exists(folderPath))
        {
            AnsiConsole.MarkupLine("[red]Папка не существует.[/]");
            return;
        }

        if (string.IsNullOrEmpty(filepath) || !File.Exists(filepath))
        {
            AnsiConsole.MarkupLine("[yellow]Файл с треками не загружен в программу[/]");

            string choice = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите способ создания файла:")
                    .AddChoices(["Загрузить существующий файл", "Ввести полный путь к новому файлу", "Ввести только название файла (файл сохранится в папку MusicMaterials)", "Использовать стандартное имя и путь"])
            );

            string savingPath = null;
            string fileName = null;

            if (choice == "Загрузить существующий файл")
            {
                filepath = AnsiConsole.Prompt(
                    new TextPrompt<string>("Введите полный путь к существующему файлу:")
                        .PromptStyle("yellow")
                );

                if (!File.Exists(filepath))
                {
                    AnsiConsole.MarkupLine("[red]Указанный файл не существует. Создаем новый файл.[/]");
                    choice = "Использовать стандартное имя";
                }
            }

            if (choice == "Ввести полный путь")
            {
                savingPath = AnsiConsole.Prompt(
                    new TextPrompt<string>("Введите полный путь для сохранения файла (без имени файла):")
                        .PromptStyle("yellow")
                );

                fileName = AnsiConsole.Prompt(
                    new TextPrompt<string>("Введите имя файла (с расширением .txt):")
                        .PromptStyle("yellow")
                        .DefaultValue("tracks.txt")
                );
                filepath = Path.Combine(savingPath, fileName);
            }
            else if (choice == "Ввести только название файла")
            {
                savingPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\MusicMaterials"));
                _ = Directory.CreateDirectory(savingPath);

                fileName = AnsiConsole.Prompt(
                    new TextPrompt<string>("Введите имя файла (с расширением .txt):")
                        .PromptStyle("yellow")
                        .DefaultValue("tracks.txt")
                );
                filepath = Path.Combine(savingPath, fileName);
            }
            else if (choice == "Использовать стандартное имя")
            {
                savingPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\MusicMaterials"));
                _ = Directory.CreateDirectory(savingPath);

                fileName = "tracks.txt";
                filepath = Path.Combine(savingPath, fileName);
            }

            if (File.Exists(filepath))
            {
                bool overwrite = AnsiConsole.Confirm($"Файл уже существует: {filepath}. Перезаписать его?");
                if (!overwrite)
                {
                    AnsiConsole.MarkupLine("[yellow]Операция отменена пользователем.[/]");
                    return;
                }
            }

            File.Create(filepath).Close();
            AnsiConsole.MarkupLine($"[green]Файл успешно создан: {filepath}[/]");
        }

        List<string> files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories)
            .Where(file => file.EndsWith(".mp3") || file.EndsWith(".flac") || file.EndsWith(".ogg"))
            .ToList();

        foreach (string file in files)
        {
            try
            {
                Track track = AdditiveFunctions.ExtractMetadata(file);

                if (AdditiveFunctions.IsUnknown(track.Title) || AdditiveFunctions.IsUnknown(track.Artist))
                {
                    List<Track> correctedTracks = await MusicBrainzService.UpdateInfo(track.Title, track.Artist);
                    if (correctedTracks.Count > 0)
                    {
                        AnsiConsole.MarkupLine($"[yellow]Информация о треке дополняется из сервиса MusicBrainz.[/]");
                        track.Title = correctedTracks[0].Title;
                        track.Artist = correctedTracks[0].Artist;
                        track.Album = correctedTracks[0].Album;
                        track.Year = correctedTracks[0].Year;
                        track.Genre = correctedTracks[0].Genre;
                    }
                    else
                    {
                        AnsiConsole.MarkupLine($"[yellow]Не удалось найти информацию о треке {track.Title} в MusicBrainz.[/]");
                    }
                }

                if (AdditiveFunctions.IsUnknown(track.Title))
                {
                    track.Title = AnsiConsole.Prompt(
                        new TextPrompt<string>("Введите название трека:")
                            .DefaultValue(Path.GetFileNameWithoutExtension(file))
                    );
                }

                if (AdditiveFunctions.IsUnknown(track.Artist))
                {
                    track.Artist = AnsiConsole.Prompt(
                        new TextPrompt<string>($"Введите имя исполнителя для трека {track.Title}:")
                            .DefaultValue("Unknown Artist")
                    );
                }

                if (AdditiveFunctions.IsUnknown(track.Album))
                {
                    track.Album = AnsiConsole.Prompt(
                        new TextPrompt<string>($"Введите название альбома для трека {track.Title} исполнителя {track.Artist}:")
                            .DefaultValue("Unknown Album")
                    );
                }

                if (track.Year == 0)
                {
                    track.Year = AnsiConsole.Prompt(
                        new TextPrompt<int>($"Введите год выпуска для трека {track.Title} исполнителя {track.Artist}:")
                            .DefaultValue(0)
                    );
                }

                if (AdditiveFunctions.IsUnknown(track.Genre))
                {
                    track.Genre = AnsiConsole.Prompt(
                        new TextPrompt<string>($"Введите жанр для трека {track.Title} исполнителя {track.Artist}:")
                            .DefaultValue("Unknown Genre")
                    );
                }

                AnsiConsole.MarkupLine($"[green]Название:[/] {track.Title}");
                AnsiConsole.MarkupLine($"[green]Исполнитель:[/] {track.Artist}");
                AnsiConsole.MarkupLine($"[green]Альбом:[/] {track.Album}");
                AnsiConsole.MarkupLine($"[green]Год:[/] {track.Year}");
                AnsiConsole.MarkupLine($"[green]Жанр:[/] {track.Genre}");

                using (StreamWriter writer = new(filepath, append: true))
                {
                    writer.WriteLine($"[{track.Title}] [{track.Artist}] [{track.Album}] [{track.Year}] [{track.Genre}] [{track.FilePath}]");
                }

                organizer = new(filepath);
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при обработке файла {file}: {ex.Message}[/]");
            }
        }

        AnsiConsole.MarkupLine($"[green]Все треки успешно добавлены в файл: {filepath}[/]");
    }
}