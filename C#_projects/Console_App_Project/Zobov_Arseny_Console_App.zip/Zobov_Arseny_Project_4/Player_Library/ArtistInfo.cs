﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_Library
{
    /// <summary>
    /// Класс для работы с получением информации об артисте
    /// </summary>
    /// <param name="name">Имя (никнейм)</param>
    /// <param name="country">Страна</param>
    /// <param name="beginDate">Дата основания</param>
    /// <param name="endDate">Дата распада</param>
    /// <param name="members">Участники</param>
    /// <param name="url">Ссылка на страниццу в MusicBrainz</param>
    public class ArtistInfo(string name, string country, string beginDate, string endDate, string members, string url)
    {
        public string Name { get; } = name;
        public string Country { get; } = country;
        public string BeginDate { get; } = beginDate;
        public string EndDate { get; } = endDate;
        public string Members { get; } = members;
        public string Url { get; } = url;

        public override string ToString()
        {
            return $"Имя: {Name}\nСтрана: {Country}\nДата основания: {BeginDate}\nДата распада: {EndDate}\nУчастники: {Members}\nСсылка: [link={Url}]Перейти к странице исполнителя[/]";
        }
    }
}
