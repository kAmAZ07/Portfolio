﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using MetaBrainz.MusicBrainz;
using Newtonsoft.Json.Linq;
using Spectre.Console;
using System;
using System.Net;

namespace Player_Library
{

    /// <summary>
    /// Статический класс для взаимодействия с API MusicBrainz
    /// Предоставляет методы для поиска информации о треках, исполнителях, альбомах и других музыкальных данных
    /// </summary>

    // AI_INSPIRATION_1
    public static class MusicBrainzService
    {
        private static readonly HttpClient httpClient;

        static MusicBrainzService()
        {
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("MusicPlayer/1.0 (zobovenok@google.com)");
        }

        /// <summary>
        /// Получает информацию о треке из MusicBrainz по названию и исполнителю.
        /// </summary>
        /// <param name="trackTitle">Название трека.</param>
        /// <param name="artistName">Имя исполнителя.</param>
        /// <returns>Список треков, соответствующих запросу. Возвращает пустой список, если данные не найдены.</returns>
        public static async Task<List<Track>> UpdateInfo(string trackTitle, string artistName)
        {
            try
            {
                string query = Uri.EscapeDataString($"\"{trackTitle}\" AND artist:\"{artistName}\"");
                string url = $"https://musicbrainz.nl.kerblif.space/ws/2/release/?query={query}&fmt=json";

                string response = await AnsiConsole.Status()
                    .Spinner(Spinner.Known.Star)
                    .SpinnerStyle(Style.Parse("green bold"))
                    .StartAsync("Загрузка данных из MusicBrainz...", async ctx => await httpClient.GetStringAsync(url));

                JObject jsonResponse = JObject.Parse(response);
                JArray releases = (JArray)jsonResponse["releases"];

                if (releases == null || releases.Count == 0)
                {
                    AnsiConsole.MarkupLine("[yellow]Не удалось найти данные для выбранного трека.[/]");
                    return [];
                }

                List<Track> tracks = releases.Select(release =>
                {
                    string title = release["title"]?.ToString() ?? "Unknown Title";
                    string artist = release["artist-credit"]?[0]?["artist"]?["name"]?.ToString() ?? "Unknown Artist";
                    string album = title;
                    int year = 0;

                    if (release["date"] != null && int.TryParse(release["date"].ToString().AsSpan(0, 4), out int parsedYear))
                    {
                        year = parsedYear;
                    }

                    string genre = "Unknown Genre";

                    return new Track(
                        title: title,
                        artist: artist,
                        album: album,
                        year: year,
                        genre: genre,
                        filePath: string.Empty
                    );
                }).ToList();

                return tracks;
            }
            catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.BadRequest)
            {
                AnsiConsole.MarkupLine("[red]Ошибка: Некорректный запрос. Проверьте введенные данные.[/]");
                return [];
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при получении данных из MusicBrainz: {ex.Message}[/]");
                return [];
            }
        }

        /// <summary>
        /// Получает информацию о треке из MusicBrainz по его MBID (идентификатору).
        /// </summary>
        /// <param name="mbid">MBID трека.</param>
        /// <returns>Объект Track с информацией о треке. Возвращает null, если данные не найдены или произошла ошибка.</returns>
        public static Track GetInfoByMBID(string mbid)
        {
            try
            {
                if (string.IsNullOrEmpty(mbid) || !Guid.TryParse(mbid, out _))
                {
                    AnsiConsole.MarkupLine("[red]Некорректный MBID. Пожалуйста, введите действительный идентификатор.[/]");
                    return null;
                }

                string url = $"https://musicbrainz.nl.kerblif.space/ws/2/recording/{mbid}?inc=artist-credits+releases&fmt=json";

                string response = AnsiConsole.Status()
                    .Spinner(Spinner.Known.Star)
                    .SpinnerStyle(Style.Parse("green bold"))
                    .Start("Загрузка данных из MusicBrainz...", ctx =>
                        httpClient.GetStringAsync(url).Result);
                AnsiConsole.MarkupLine($"[grey]Ответ от API:[/] {response}");

                JObject jsonResponse = JObject.Parse(response);
                string title = jsonResponse["title"]?.ToString() ?? "Unknown Title";
                string artist = jsonResponse["artist-credit"]?[0]?["artist"]?["name"]?.ToString() ?? "Unknown Artist";
                string album = "Unknown Album";
                int year = 0;

                if (jsonResponse["releases"] != null && jsonResponse["releases"].Any())
                {
                    album = jsonResponse["releases"]?[0]?["title"]?.ToString() ?? "Unknown Album";
                    if (jsonResponse["releases"]?[0]?["date"] != null &&
                        int.TryParse(jsonResponse["releases"][0]["date"].ToString()[..4], out int parsedYear))
                    {
                        year = parsedYear;
                    }
                }
                else
                {
                    AnsiConsole.MarkupLine("[yellow]Для этого трека отсутствуют данные об альбоме.[/]");
                }

                return new Track(
                    title: title,
                    artist: artist,
                    album: album,
                    year: year,
                    genre: "Unknown Genre",
                    filePath: string.Empty,
                    mbid: mbid
                );
            }
            catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.BadRequest)
            {
                AnsiConsole.MarkupLine("[red]Ошибка: Некорректный запрос. Проверьте введенные данные.[/]");
                return null;
            }
            catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                AnsiConsole.MarkupLine("[red]Ошибка: Трек с указанным MBID не найден.[/]");
                return null;
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при получении данных из MusicBrainz: {ex.Message}[/]");
                return null;
            }
        }

        /// <summary>
        /// Ищет исполнителей по имени в MusicBrainz.
        /// </summary>
        /// <param name="artistName">Имя исполнителя для поиска.</param>
        /// <returns>Список исполнителей, соответствующих запросу. Возвращает пустой список, если данные не найдены.</returns>
        public static List<ArtistListOfResults> SearchArtists(string artistName)
        {
            try
            {
                string query = Uri.EscapeDataString(artistName);
                string url = $"https://musicbrainz.nl.kerblif.space/ws/2/artist/?query={query}&fmt=json";

                string response = AnsiConsole.Status()
                    .Spinner(Spinner.Known.Star)
                    .SpinnerStyle(Style.Parse("green bold"))
                    .Start("Загрузка данных из MusicBrainz...", ctx =>
                        httpClient.GetStringAsync(url).Result);

                JObject jsonResponse = JObject.Parse(response);
                JArray artists = (JArray)jsonResponse["artists"];

                if (artists == null || artists.Count == 0)
                {
                    AnsiConsole.MarkupLine("[yellow]Исполнители не найдены.[/]");
                    return [];
                }

                return artists.Select(artist => new ArtistListOfResults
                {
                    Id = artist["id"]?.ToString(),
                    Name = artist["name"]?.ToString() ?? "Unknown Artist",
                    Country = artist["country"]?.ToString() ?? "Unknown Country",
                    Type = artist["type"]?.ToString() ?? "Unknown Type"
                }).ToList();
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при поиске исполнителя: {ex.Message}[/]");
                return [];
            }
        }

        /// <summary>
        /// Получает подробную информацию об исполнителе по его MBID.
        /// </summary>
        /// <param name="artistMbid">MBID исполнителя.</param>
        /// <returns>Объект ArtistInfo с информацией об исполнителе. Возвращает null, если данные не найдены или произошла ошибка.</returns>
        public static ArtistInfo GetArtistInfo(string artistMbid)
        {
            try
            {
                string url = $"https://musicbrainz.nl.kerblif.space/ws/2/artist/{artistMbid}?inc=url-rels&fmt=json";
                string response = AnsiConsole.Status()
                    .Spinner(Spinner.Known.Star)
                    .SpinnerStyle(Style.Parse("green bold"))
                    .Start("Загрузка данных из MusicBrainz...", ctx =>
                        httpClient.GetStringAsync(url).Result);

                JObject jsonResponse = JObject.Parse(response);
                string name = jsonResponse["name"]?.ToString() ?? "Unknown Artist";
                string country = jsonResponse["country"]?.ToString() ?? "Unknown Country";
                string beginDate = jsonResponse["life-span"]?["begin"]?.ToString() ?? "Unknown";
                string endDate = jsonResponse["life-span"]?["end"]?.ToString() ?? "Present";

                string artistUrl = $"https://musicbrainz.nl.kerblif.space/artist/{artistMbid}";

                List<string?> members = jsonResponse["relations"]?
                    .Where(rel => rel["type"]?.ToString() == "member of band")
                    .Select(rel => rel["artist"]?["name"]?.ToString())
                    .ToList() ?? [];

                string membersList = members.Count != 0 ? string.Join(", ", members) : "Unknown Members";

                return new ArtistInfo(name, country, beginDate, endDate, membersList, artistUrl);
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при получении данных об исполнителе: {ex.Message}[/]");
                return null;
            }
        }

        /// <summary>
        /// Ищет альбомы по названию в MusicBrainz.
        /// </summary>
        /// <param name="albumName">Название альбома для поиска.</param>
        /// <returns>Список альбомов, соответствующих запросу. Возвращает пустой список, если данные не найдены.</returns>
        public static List<AlbumListOfResults> SearchAlbums(string albumName)
        {
            try
            {
                string query = Uri.EscapeDataString(albumName);
                string url = $"https://musicbrainz.nl.kerblif.space/ws/2/release/?query={query}&fmt=json";
                string response = AnsiConsole.Status()
                    .Spinner(Spinner.Known.Star)
                    .SpinnerStyle(Style.Parse("green bold"))
                    .Start("Загрузка данных из MusicBrainz...", ctx =>
                    httpClient.GetStringAsync(url).Result);

                JObject jsonResponse = JObject.Parse(response);
                JArray releases = (JArray)jsonResponse["releases"];

                if (releases == null || releases.Count == 0)
                {
                    AnsiConsole.MarkupLine("[yellow]Альбомы не найдены.[/]");
                    return [];
                }

                return releases.Select(release => new AlbumListOfResults
                {
                    Id = release["id"]?.ToString(),
                    Title = release["title"]?.ToString() ?? "Unknown Album",
                    Artist = release["artist-credit"]?[0]?["artist"]?["name"]?.ToString() ?? "Unknown Artist",
                    Date = release["date"]?.ToString() ?? "Unknown Date"
                }).ToList();
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при поиске альбома: {ex.Message}[/]");
                return [];
            }
        }

        /// <summary>
        /// Получает подробную информацию об альбоме по его MBID.
        /// </summary>
        /// <param name="albumMbid">MBID альбома.</param>
        /// <returns>Объект AlbumInfo с информацией об альбоме. Возвращает null, если данные не найдены или произошла ошибка.</returns>
        public static AlbumInfo GetAlbumInfo(string albumMbid)
        {
            try
            {
                string url = $"https://musicbrainz.nl.kerblif.space/ws/2/release/{albumMbid}?inc=recordings+labels+release-groups&fmt=json";
                string response = AnsiConsole.Status()
                    .Spinner(Spinner.Known.Star)
                    .SpinnerStyle(Style.Parse("green bold"))
                    .Start("Загрузка данных из MusicBrainz...", ctx =>
                        httpClient.GetStringAsync(url).Result);

                JObject jsonResponse = JObject.Parse(response);
                string title = jsonResponse["title"]?.ToString() ?? "Unknown Album";
                string artist = jsonResponse["artist-credit"]?[0]?["artist"]?["name"]?.ToString() ?? "Unknown Artist";
                string releaseDate = jsonResponse["date"]?.ToString() ?? "Unknown Date";
                string label = jsonResponse["label-info"]?[0]?["label"]?["name"]?.ToString() ?? "Unknown Label";

                List<string?> trackList = jsonResponse["media"]?[0]?["tracks"]?
                    .Select(track => track["title"]?.ToString())
                    .ToList() ?? [];

                string trackListString = trackList.Count != 0 ? string.Join(", ", trackList) : "Unknown Tracklist";

                string albumUrl = $"https://musicbrainz.nl.kerblif.space/release/{albumMbid}";

                return new AlbumInfo(title, artist, releaseDate, label, trackListString, albumUrl);
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при получении данных об альбоме: {ex.Message}[/]");
                return null;
            }
        }

        /// <summary>
        /// Рассчитывает расстояние Левенштейна между двумя строками. Теоретически предназванчен для того, чтобы обрабатывались опечатки.
        /// </summary>
        /// <param name="s">Первая строка</param>
        /// <param name="t">Вторая строка</param>
        /// <returns>Целочисленное значение, представляющее расстояние Левенштейна между строками, предназванченное для дальнейшей обработки программой</returns>
        public static int LevenshteinDistance(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];

            if (n == 0)
            {
                return m;
            }

            if (m == 0)
            {
                return n;
            }

            for (int i = 0; i <= n; i++)
            {
                d[i, 0] = i;
            }

            for (int j = 0; j <= m; j++)
            {
                d[0, j] = j;
            }

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }

            return d[n, m];
        }

        /// <summary>
        /// Находит наиболее похожий вариант из списка строк на основе расстояния Левенштейна.
        /// </summary>
        /// <param name="input">Строка для сравнения.</param>
        /// <param name="options">Список строк для поиска наиболее похожего варианта.</param>
        /// <returns>Наиболее похожая строка из списка. Возвращает пустую строку, если список пуст.</returns>
        public static string FindBestMatch(string input, IEnumerable<string> options)
        {
            return options
                .OrderBy(option => LevenshteinDistance(input.ToLower(), option.ToLower()))
                .FirstOrDefault() ?? string.Empty;
        }
    }
}
