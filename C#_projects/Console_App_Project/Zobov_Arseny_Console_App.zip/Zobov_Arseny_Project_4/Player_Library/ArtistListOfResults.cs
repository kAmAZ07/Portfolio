﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_Library
{
    /// <summary>
    /// Класс для отображения списка найденных артистов
    /// </summary>
    public class ArtistListOfResults
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
        public string Type { get; set; }

        public override string ToString()
        {
            return $"{Name} ({Country})";
        }
    }
}
