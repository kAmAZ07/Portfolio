﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_Library
{
    /// <summary>
    /// Класс для первичного отбора для вывода списка полученных результатов
    /// </summary>
    public class AlbumListOfResults
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Artist { get; set; }
        public string Date { get; set; }

        public override string ToString()
        {
            return $"{Title} ({Artist}, {Date})";
        }
    }
}
