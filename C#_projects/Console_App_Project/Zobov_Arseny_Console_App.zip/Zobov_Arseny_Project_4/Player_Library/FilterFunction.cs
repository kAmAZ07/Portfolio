﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_Library
{
    /// <summary>
    /// Метод для фильтра треков
    /// </summary>
    /// <param name="field">название поля</param>
    /// <param name="value">значение по полю</param>
    public class FilterFunction(string field, string value) : TrackOperations
    {
        public string Field { get; } = field;
        public string Value { get; } = value;

        public override void Apply(List<Track> tracks)
        {
            switch (Field.ToLower())
            {
                case "исполнителю":
                    _ = tracks.RemoveAll(t => !t.Artist.Contains(Value, StringComparison.OrdinalIgnoreCase));
                    break;
                case "альбому":
                    _ = tracks.RemoveAll(t => !t.Album.Contains(Value, StringComparison.OrdinalIgnoreCase));
                    break;
                case "году":
                    if (int.TryParse(Value, out int year))
                    {
                        _ = tracks.RemoveAll(t => t.Year != year);
                    }
                    break;
                case "жанру":
                    _ = tracks.RemoveAll(t => !t.Genre.Contains(Value, StringComparison.OrdinalIgnoreCase));
                    break;
            }
        }

        public override string ToString()
        {
            return $"Фильтрация по {Field}: {Value}";
        }
    }
}
