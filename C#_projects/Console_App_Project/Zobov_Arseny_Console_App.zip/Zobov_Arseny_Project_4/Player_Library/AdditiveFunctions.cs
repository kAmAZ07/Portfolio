﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using Spectre.Console;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_Library
{
    /// <summary>
    /// Класс, содержащий вспомогательные функции для работы с треками и операциями над ними.
    /// </summary>
    public class AdditiveFunctions
    {

        // <summary>
        /// Добавляет операцию (фильтрацию или сортировку) в список операций.
        /// </summary>
        /// <param name="operations">Список операций, в который будет добавлена новая операция.</param>
        public static void AddOperation(List<TrackOperations> operations)
        {
            string type = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите тип операции:")
                    .AddChoices(["Фильтрация", "Сортировка"])
            );

            if (type == "Фильтрация")
            {
                string field = AnsiConsole.Prompt(
                    new SelectionPrompt<string>()
                        .Title("Фильтровать по:")
                        .AddChoices(["Исполнителю", "Альбому", "Году", "Жанру"])
                );
                string value = AnsiConsole.Ask<string>("Введите значение для фильтрации:");
                operations.Add(new FilterFunction(field, value));
            }
            else if (type == "Сортировка")
            {
                string field = AnsiConsole.Prompt(
                    new SelectionPrompt<string>()
                        .Title("Сортировать по:")
                        .AddChoices(["Названию", "Исполнителю", "Альбому", "Году", "Жанру"])
                );
                operations.Add(new SortFunction(field));
            }

            AnsiConsole.MarkupLine("[green]Операция успешно добавлена![/]");
        }

        /// <summary>
        /// Удаляет операцию из списка операций.
        /// </summary>
        /// <param name="operations">Список операций, из которого будет удалена операция.</param>
        public static void RemoveOperation(List<TrackOperations> operations)
        {
            if (operations.Count == 0)
            {
                AnsiConsole.MarkupLine("[yellow]Нет операций для удаления.[/]");
                return;
            }

            string index = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("Выберите операцию для удаления:")
                    .AddChoices(operations.Select((op, i) => $"{i + 1}. {op}"))
            );

            int selectedIndex = int.Parse(index.Split('.')[0]) - 1;
            operations.RemoveAt(selectedIndex);
            AnsiConsole.MarkupLine("[green]Операция успешно удалена![/]");
        }

        /// <summary>
        /// Форматирует время в формате mm:ss.
        /// </summary>
        /// <param name="seconds">Время в секундах.</param>
        /// <returns>Строка времени в формате mm:ss.</returns>
        public static string FormatTime(double seconds)
        {
            int minutes = (int)seconds / 60;
            int remainingSeconds = (int)seconds % 60;
            return $"{minutes:D2}:{remainingSeconds:D2}";
        }

        /// <summary>
        /// Проверяет, является ли значение "неизвестным"
        /// </summary>
        /// <param name="value">Значение поля (какого-то) аудиофайла</param>
        /// <returns>True, если значение пустое или начинается с "Unknown"</returns>
        public static bool IsUnknown(string value)
        {
            return string.IsNullOrEmpty(value) || value.StartsWith("Unknown", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Извлекает метаданные из аудиофайла
        /// </summary>
        /// <param name="filePath">Путь к аудиофайлу</param>
        /// <returns>Объект Track с извлеченными метаданными; null, если произошла ошибка</returns>

        public static Track ExtractMetadata(string filePath)
        {
            try
            {
                TagLib.File tagFile = TagLib.File.Create(filePath);

                string title = tagFile.Tag.Title ?? Path.GetFileNameWithoutExtension(filePath);
                string artist = tagFile.Tag.FirstAlbumArtist
                    ?? tagFile.Tag.AlbumArtists.FirstOrDefault()
                    ?? tagFile.Tag.Performers.FirstOrDefault()
                    ?? "Unknown Artist";
                string album = tagFile.Tag.Album ?? "Unknown Album";
                int year = tagFile.Tag.Year > 0 ? (int)tagFile.Tag.Year : 0;
                string genre = tagFile.Tag.Genres.Length > 0 ? tagFile.Tag.Genres[0] : "Unknown Genre";

                return new Track(
                    title: title,
                    artist: artist,
                    album: album,
                    year: year,
                    genre: genre,
                    filePath: filePath
                );
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Ошибка при извлечении метаданных из файла {filePath}: {ex.Message}[/]");
                return null;
            }
        }
    }
}
