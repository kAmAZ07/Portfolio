﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_Library
{
    /// <summary>
    /// Класс для работы с объектом альбома (для получения из MusicBrainz)
    /// </summary>
    /// <param name="title">Название альбома</param>
    /// <param name="artist">Имя исполнителя</param>
    /// <param name="releaseDate">Дата релиза</param>
    /// <param name="label">Под каким лейблом выпущен</param>
    /// <param name="trackList">главный трек альбома</param>
    /// <param name="url">ссылка на альбом (musicbrainz)</param>
    public class AlbumInfo(string title, string artist, string releaseDate, string label, string trackList, string url)
    {
        public string Title { get; } = title;
        public string Artist { get; } = artist;
        public string ReleaseDate { get; } = releaseDate;
        public string Label { get; } = label;
        public string TrackList { get; } = trackList;
        public string Url { get; } = url;

        public override string ToString()
        {
            return $"Название: {Title}\nИсполнитель: {Artist}\nДата релиза: {ReleaseDate}\nЛейбл: {Label}\nТреклист: {TrackList}\nСсылка: [link={Url}]Перейти к странице альбома[/]";
        }
    }
}
