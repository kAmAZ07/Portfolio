﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_Library
{
    /// <summary>
    /// Функция для сортировки треков
    /// </summary>
    /// <param name="field">поле для сортировки</param>
    public class SortFunction(string field) : TrackOperations
    {
        public string Field { get; } = field;

        public override void Apply(List<Track> tracks)
        {
            switch (Field.ToLower())
            {
                case "названию":
                    tracks.Sort((x, y) => string.Compare(x.Title, y.Title, StringComparison.OrdinalIgnoreCase));
                    break;
                case "исполнителю":
                    tracks.Sort((x, y) => string.Compare(x.Artist, y.Artist, StringComparison.OrdinalIgnoreCase));
                    break;
                case "альбому":
                    tracks.Sort((x, y) => string.Compare(x.Album, y.Album, StringComparison.OrdinalIgnoreCase));
                    break;
                case "году":
                    tracks.Sort((x, y) => x.Year.CompareTo(y.Year));
                    break;
                case "жанру":
                    tracks.Sort((x, y) => string.Compare(x.Genre, y.Genre, StringComparison.OrdinalIgnoreCase));
                    break;
            }
        }

        public override string ToString()
        {
            return $"Сортировка по {Field}";
        }
    }
}
