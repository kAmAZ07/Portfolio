﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;

namespace Player_Library
{
    /// <summary>
    /// Класс объекта Трек
    /// </summary>
    /// <param name="title">Название</param>
    /// <param name="artist">Исполнитель</param>
    /// <param name="album">Альбом трека</param>
    /// <param name="year">Год выпуска</param>
    /// <param name="genre">Жанр</param>
    /// <param name="filePath">ссылка на воспроизведение</param>
    /// <param name="mbid">MBID</param>
    public class Track(string title, string artist, string album, int year, string genre, string filePath, string mbid = "")
    {
        public string Title { get; set; } = title;
        public string Artist { get; set; } = artist;
        public string Album { get; set; } = album;
        public int Year { get; set; } = year;
        public string Genre { get; set; } = genre;
        public string FilePath { get; set; } = filePath;

        public override string ToString()
        {
            return $"Название: {Title}\nИсполнитель: {Artist}\nАльбом: {Album}\nГод выпуска: {Year}\nЖанр: {Genre}";
        }
    }
}
