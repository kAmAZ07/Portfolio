﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;

namespace Player_Library
{
    /// <summary>
    /// абстрактный класс для фильтрации и сортиировки
    /// </summary>
    public abstract class TrackOperations
    {
        public abstract void Apply(List<Track> tracks);
    }
}



