﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NAudio.Wave;

namespace Player_Library
{

    /// <summary>
    /// Статический класс для управления воспроизведением аудиофайлов.
    /// Предоставляет функционал для воспроизведения, остановки, паузы, возобновления и перемотки треков.
    /// </summary>
    public static class TrackPlayer
    {
        private static WaveOutEvent? _outputDevice;
        private static AudioFileReader? _audioFile;

        /// <summary>
        /// Воспроизводит аудиофайл по указанному пути.
        /// </summary>
        /// <param name="filePath">Путь к аудиофайлу.</param>
        public static void Play(string filePath)
        {
            Stop();
            _audioFile = new AudioFileReader(filePath);
            _outputDevice = new WaveOutEvent();
            _outputDevice.Init(_audioFile);
            _outputDevice.Play();
        }

        /// <summary>
        /// Останавливает воспроизведение и освобождает ресурсы.
        /// </summary>
        public static void Stop()
        {
            if (_outputDevice != null && _outputDevice.PlaybackState == PlaybackState.Playing)
            {
                _outputDevice.Stop();
            }
            _outputDevice?.Dispose();
            _audioFile?.Dispose();
        }

        /// <summary>
        /// Перематывает позицию воспроизведения на указанное количество секунд.
        /// </summary>
        /// <param name="positionInSeconds">Позиция в секундах для перемотки.</param>
        public static void Rewind(int positionInSeconds)
        {
            if (_audioFile != null)
            {
                _audioFile.CurrentTime = TimeSpan.FromSeconds(positionInSeconds);
            }
        }

        /// <summary>
        /// Возвращает текущую позицию воспроизведения в секундах.
        /// </summary>
        /// <returns>Текущая позиция воспроизведения в секундах. Возвращает 0, если файл не загружен.</returns>
        public static int GetCurrentPosition()
        {
            return _audioFile != null ? (int)_audioFile.CurrentTime.TotalSeconds : 0;
        }

        /// <summary>
        /// Возвращает общую длительность трека в секундах.
        /// </summary>
        /// <returns>Общая длительность трека в секундах. Возвращает 0, если файл не загружен.</returns>
        public static int GetTotalDuration()
        {
            return _audioFile != null ? (int)_audioFile.TotalTime.TotalSeconds : 0;
        }

        /// <summary>
        /// Приостанавливает воспроизведение трека.
        /// </summary>
        public static void Pause()
        {
            if (_outputDevice != null && _outputDevice.PlaybackState == PlaybackState.Playing)
            {
                _outputDevice.Pause();
            }
        }

        /// <summary>
        /// Возобновляет воспроизведение приостановленного трека.
        /// </summary>
        public static void Resume()
        {
            if (_outputDevice != null && _outputDevice.PlaybackState == PlaybackState.Paused)
            {
                _outputDevice.Play();
            }
        }
    }
}
