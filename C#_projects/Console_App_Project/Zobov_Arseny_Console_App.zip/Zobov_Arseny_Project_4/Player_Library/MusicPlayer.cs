﻿/*
 * Зобов Арсений Александрович
 * БПИ 245-2
 * Проект #4
 * Вариант 9
 * B-side
 */

using Spectre.Console;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Player_Library
{
    /// <summary>
    /// Класс методов для основной задачи
    /// Управляет загрузкой, сохранением, редактированием и удалением треков
    /// </summary>
    public class MusicPlayer
    {
        private static readonly List<Track> tracks = [];
        private readonly string filePath;

        /// <summary>
        /// Инициализирует новый экземпляр класса MusicPlayer.
        /// </summary>
        /// <param name="filePath">Путь к файлу с треками (txt или csv).</param>
        public MusicPlayer(string filePath)
        {
            this.filePath = filePath.Trim().Trim('\"'); ;
            if (filePath[^3..] == "txt")
            {
                LoadTracks();
            }
            else if (filePath[^3..] == "csv")
            {
                ImportFromCsv();
            }
            else
            {
                AnsiConsole.MarkupLine($"[red]Недопустимый формат файла[/]");
            }
        }

        /// <summary>
        /// Загружает треки из текстового файла.
        /// </summary>
        public void LoadTracks()
        {
            if (!File.Exists(filePath))
            {
                File.Create(filePath).Close();
            }

            tracks.Clear();

            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                string[] parts = line.Split([']'], StringSplitOptions.RemoveEmptyEntries)
                                     .Select(part => part.Trim('[', ' ', '\t'))
                                     .ToArray();

                if (parts.Length < 6)
                {
                    Array.Resize(ref parts, 6);
                    for (int i = parts.Length; i < 6; i++)
                    {
                        parts[i] = string.Empty;
                    }
                }

                if (parts.Length == 6 && int.TryParse(parts[3], out int year))
                {
                    tracks.Add(new Track(
                        parts[0],
                        parts[1],
                        parts[2],
                        year,
                        parts[4],
                        parts[5]
                    ));
                }
            }
        }

        /// <summary>
        /// Импортирует треки из CSV-файла.
        /// </summary>
        public void ImportFromCsv()
        {
            if (!File.Exists(filePath))
            {
                File.Create(filePath).Close();
            }

            tracks.Clear();
            List<Track> lines = File.ReadAllLines(filePath)
                .Skip(1)
                .Select(line =>
                {
                    string[] parts = line.Split(',');
                    return new Track(
                        title: parts[0],
                        artist: parts[1],
                        album: parts[2],
                        year: int.TryParse(parts[3], out int year) ? year : 0,
                        genre: parts[4],
                        filePath: parts[5]
                    );
                })
                .ToList();

            foreach (Track track in lines)
            {
                tracks.Add(track);
            }

            AnsiConsole.MarkupLine($"[green]Импортировано {tracks.Count} треков из файла: {filePath}[/]");
        }

        /// <summary>
        /// Сохраняет текущий список треков в файл.
        /// </summary>
        public void SaveTracks()
        {
            IEnumerable<string> lines = tracks.Select(track =>
                $"[{track.Title}] [{track.Artist}] [{track.Album}] [{track.Year}] [{track.Genre}] [{track.FilePath}]");
            File.WriteAllLines(filePath, lines);
        }

        /// <summary>
        /// Возвращает список всех треков.
        /// </summary>
        /// <returns>Список треков.</returns>
        public static List<Track> GetTracks()
        {
            return tracks;
        }

        /// <summary>
        /// Добавляет новый трек в список, если он еще не существует.
        /// </summary>
        /// <param name="track">Трек для добавления.</param>
        /// <param name="filePath">Путь к файлу для сохранения треков.</param>
        /// <exception cref="ArgumentException">Выбрасывается, если трек уже существует в списке.</exception>
        public static void AddTrack(Track track, string filePath)
        {
            if (!tracks.Any(t => t.Title == track.Title && t.Artist == track.Artist && t.FilePath == track.FilePath))
            {
                tracks.Add(track);
                SaveTracksToFile(filePath);
            }
            else
            {
                throw new ArgumentException($"[yellow]Трек уже существует в списке:[/]\n{track}");
            }
        }

        /// <summary>
        /// Редактирует трек по указанному индексу.
        /// </summary>
        /// <param name="index">Индекс трека для редактирования.</param>
        /// <param name="updatedTrack">Обновленный трек.</param>
        public static void EditTrack(int index, Track updatedTrack)
        {
            if (index >= 0 && index < tracks.Count)
            {
                tracks[index] = updatedTrack;
            }
        }

        /// <summary>
        /// Удаляет трек по указанному индексу.
        /// </summary>
        /// <param name="index">Индекс трека для удаления.</param>
        public static void RemoveTrack(int index)
        {
            if (index >= 0 && index < tracks.Count)
            {
                tracks.RemoveAt(index);
            }
        }

        /// <summary>
        /// Сохраняет текущий список треков в указанный файл.
        /// </summary>
        /// <param name="filePath">Путь к файлу для сохранения треков.</param>
        public static void SaveTracksToFile(string filePath)
        {
            using StreamWriter writer = new(filePath, append: false);
            foreach (Track track in tracks)
            {
                writer.WriteLine($"[{track.Title}] [{track.Artist}] [{track.Album}] [{track.Year}] [{track.Genre}] [{track.FilePath}]");
            }
        }

        /// <summary>
        /// Запрашивает ввод строки у пользователя с проверкой на пустой ввод.
        /// Если пользователь ничего не ввел, используется значение по умолчанию.
        /// </summary>
        /// <param name="prompt">Подсказка для пользователя.</param>
        /// <param name="allowEmpty">Разрешить пустой ввод.</param>
        /// <param name="defaultValue">Значение по умолчанию, если ввод пустой.</param>
        /// <returns>Введенная строка или значение по умолчанию.</returns>
        public static string PromptInput(string prompt, bool allowEmpty, string defaultValue = "")
        {
            while (true)
            {
                AnsiConsole.Markup(prompt + " ");
                string input = Console.ReadLine();
                if (Console.KeyAvailable)
                {
                    ConsoleKey key = Console.ReadKey(intercept: true).Key;
                    if (key == ConsoleKey.Escape)
                    {
                        throw new OperationCanceledException();
                    }
                }

                if (string.IsNullOrWhiteSpace(input))
                {
                    if (!allowEmpty && string.IsNullOrEmpty(defaultValue))
                    {
                        AnsiConsole.MarkupLine("[red]Ошибка: Вы ничего не ввели. Попробуйте снова.[/]");
                        continue;
                    }
                    return string.IsNullOrEmpty(defaultValue) ? string.Empty : defaultValue.Trim();
                }

                return input.Trim();
            }
        }

        /// <summary>
        /// Запрашивает ввод года выпуска у пользователя с проверкой на корректность.
        /// Если пользователь ничего не ввел, используется значение по умолчанию.
        /// </summary>
        /// <param name="prompt">Подсказка для пользователя.</param>
        /// <param name="defaultValue">Значение по умолчанию, если ввод пустой.</param>
        /// <returns>Введенный год или значение по умолчанию.</returns>
        public static int PromptYear(string prompt, int defaultValue)
        {
            while (true)
            {
                AnsiConsole.Markup(prompt + $" (текущее значение: {defaultValue}): ");
                string input = Console.ReadLine();

                if (Console.KeyAvailable && Console.ReadKey(intercept: true).Key == ConsoleKey.Escape)
                {
                    throw new OperationCanceledException();
                }

                if (string.IsNullOrWhiteSpace(input))
                {
                    return defaultValue;
                }

                if (int.TryParse(input, out int year) && year > 0)
                {
                    return year;
                }

                AnsiConsole.MarkupLine("[red]Ошибка: Введите корректный год (положительное число).[/]");
            }
        }

    }
}