﻿
using System;

namespace ProjectHSE_2
{ 
    /// <summary>
    /// Класс объектов типа Port
    /// </summary>
    public class Port
    {
        public string Country;
        public string Port_Name;
        public string UN_Code;
        public short Vessels_in_Port;
        public short Departures;
        public short Arrivals;
        public short Expected_Arrivals;
        public string Type;
        public string Area_Local;
        public string Area_Global;
        public string Also_Known_As;
    }
}