﻿using System;
using System.Diagnostics.Metrics;
using System.Xml.Linq;

namespace ProjectHSE_2
{
    /// <summary>
    /// Класс основной программы
    /// </summary>
    internal class Program
    {
        public static string? fileName;

        /// <summary>
        /// Метод, запускающий программу
        /// </summary>
        public static void Main()
        {
            Menu menu = new("Выбери пункт:",
            [
            new MenuItem(ConsoleKey.D1, "1. Загрузить данные из файла", ReadFile),
            new MenuItem(ConsoleKey.D2, "2. Группа портов типа Port", PortsSort),
            new MenuItem(ConsoleKey.D3, "3. Список портов по стране", CountrySort),
            new MenuItem(ConsoleKey.D4, "4. Сводная статистика", Stats),
            new MenuItem(ConsoleKey.D5, "5. Переупорядоченный набор данных по названию порта", SortPort_Name),
            new MenuItem(ConsoleKey.D6, "6. Специальная выборка портов", SpecialChooseDep),
            new MenuItem(ConsoleKey.D7, "7. Выход из программы", Exit)
            ]);
            menu.Run();
        }



        /// <summary>
        /// 1 пункт меню: считывание файла с отработкой исключений
        /// </summary>
        /// <param name="menuItem">пункт меню номер 1</param>
        /// <param name="menu">меню</param>
        private static void ReadFile(MenuItem menuItem, Menu menu)
        {
            Console.Write("Введите имя файла (без указания пути): ");
            string[] lines;
            do
            {
                fileName = Console.ReadLine();
                lines = Operations_with_CSV.ReadFileCSV(fileName);
                
            } while (lines == null);
            Console.WriteLine($"Успешно загружен файл {fileName}");
            menu.Title = "Выберите действие: ";
            menu.Items = [
                new MenuItem(ConsoleKey.D1, "1. Сменить набор данных", ReadFile),
                new MenuItem(ConsoleKey.D2, "2. Группа портов типа Port", PortsSort),
                new MenuItem(ConsoleKey.D3, "3. Список портов по стране", CountrySort),
                new MenuItem(ConsoleKey.D4, "4. Сводная статистика", Stats),
                new MenuItem(ConsoleKey.D5, "5. Переупорядоченный набор данных по названию порта", SortPort_Name),
                new MenuItem(ConsoleKey.D6, "6. Специальная выборка портов", SpecialChooseDep),
                new MenuItem(ConsoleKey.D7, "7. Выход из программы", Exit)
            ];
        }

        /// <summary>
        /// Выборка строк файла с типом Port и записыванием в Port-Port.csv
        /// </summary>
        /// <param name="menuItem">пункт меню номер 2</param>
        /// <param name="menu">меню</param>
        private static void PortsSort(MenuItem menuItem, Menu menu)
        {
            string[] lines = Operations_with_CSV.ReadFileCSV(fileName);
            if (lines is null)
            {
                return;
            }
            Screen_field data = new(lines);
            List<string> portLines = [",Country,Port Name,UN Code,Vessels in Port,Departures(Last 24 Hours),Arrivals(Last 24 Hours),Expected Arrivals,Type,Area Local,Area Global,Also known as"];
            List<Port> portsType = [];
            int k = 0;
            foreach (Port pr in data.Ports)
            {
                if (pr.Type == "Port")
                {

                    portsType.Add(pr);
                    portLines.Add($"{k},{Operations_with_CSV.ConvertToString(pr)}");
                    k++;
                }
            }
            File.WriteAllLines("../../../../WorkingFiles/Port-Port.csv", portLines);

            data.PrintCollection(portsType);
            Console.WriteLine("Данные записаны в файл Port-Port.csv");
        }

        /// <summary>
        /// Выводит на экран список портов, относящихся к одной и той же стране (Country).
        /// Перед каждой группой поколения выводит строку с данными о порте, у которого
        /// больше всего судов (Vessels in Port в рамках страны)
        /// </summary>
        /// <param name="menuItem">пункт меню 3</param>
        /// <param name="menu">меню</param>
        private static void CountrySort(MenuItem menuItem, Menu menu)
        {
            string[] lines = Operations_with_CSV.ReadFileCSV(fileName);
            if (lines is null)
            {
                return;
            }

            string[] countries = Operations_with_CSV.CountField(fileName, "Country");
            for (int i = 0; i < countries.Length; i++)
            {
                string prts = "";
                Console.WriteLine($"Страна: {countries[i]}");
                Screen_field data = new(lines);
                List<string> portCLines = [",Country,Port Name,UN Code,Vessels in Port,Departures(Last 24 Hours),Arrivals(Last 24 Hours),Expected Arrivals,Type,Area Local,Area Global,Also known as"];
                List<Port> portsCountry = [];
                int maxi = 0;
                foreach (Port pr in data.Ports)
                {
                    if (pr.Country == countries[i])
                    {
                        prts = prts + pr.Port_Name.TrimEnd() + ", ";
                        if (pr.Vessels_in_Port > maxi)
                        {
                            portsCountry = [pr];
                            portCLines = [",Country,Port Name,UN Code,Vessels in Port,Departures(Last 24 Hours),Arrivals(Last 24 Hours),Expected Arrivals,Type,Area Local,Area Global,Also known as", $"{0}, {Operations_with_CSV.ConvertToString(pr)}"];
                            maxi = pr.Vessels_in_Port;
                        }
                    }
                }
                prts = prts[..^2];
                int k = 1;
                foreach (string p in prts.Split(','))
                {
                    portCLines.Add($"{k}, {countries[i]}, {p}");
                    k++;
                }
                File.WriteAllLines($"../../../../WorkingFiles/Port-Country-{countries[i]}.csv", portCLines);
                data.PrintCollection(portsCountry);
                Console.WriteLine(prts);
                Console.WriteLine($"Данные записаны в файл Port-Country-{countries[i]}.csv");
            }
        }

        /// <summary>
        /// Выводит на экран сводную статистику по данным загруженного файла: 
        /// Общее количество портов по странам(Country). 
        /// Полные данные о самом загруженном судами портом (Vessels in Port) и самом менее загруженном порте среди всех портов, загруженных из файла.
        /// Количество Yellow Sea (свойство Area Local) Bohai Sea(свойство Area Local). 
        /// Количество портов страны China, у которых Arrivals меньше среднего значения по этому показателю в данных всего файла.
        /// </summary>
        /// <param name="menuItem">пункт меню 4</param>
        /// <param name="menu">меню</param>
        private static void Stats(MenuItem menuItem, Menu menu)
        {
            int ys = 0; int bs = 0; int ch = 0; int maxi = 0; int mini = 1000000000; int sumA = 0;
            string[] lines = Operations_with_CSV.ReadFileCSV(fileName);
            if (lines is null)
            {
                return;
            }
            string[] countries = Operations_with_CSV.CountField(fileName, "Country");
            Screen_field data = new(lines);
            List<Port> portsVesselsMA = [];
            List<Port> portsVesselsMI = [];
            foreach (Port pr in data.Ports)
            {
                sumA += pr.Arrivals;
                if (pr.Vessels_in_Port > maxi)
                {
                    portsVesselsMA = [pr];
                    maxi = pr.Vessels_in_Port;
                }

                if (pr.Vessels_in_Port < mini)
                {
                    portsVesselsMI = [pr];
                    mini = pr.Vessels_in_Port;
                }
                if (pr.Area_Local == "Yellow Sea")
                {
                    ys++;
                }
                if (pr.Area_Local == "Bohai Sea")
                {
                    bs++;
                }
            }

            for (int i = 0; i < countries.Length; i++)
            {
                int prts = 0;
                Console.Write($"Страна: {countries[i]}, портов: ");
                foreach (Port pr in data.Ports)
                {
                    if (pr.Country == countries[i])
                    {
                        prts++;
                    }
                }
                Console.Write($"{prts}\n");
            }
            foreach (Port pr in data.Ports)
            {
                if (pr.Country == "China" && pr.Arrivals < (sumA / lines.Length))
                {
                    ch++;
                }
            }
            Console.WriteLine("MAXIMUM");
            data.PrintCollection(portsVesselsMA);
            Console.WriteLine("MINIMUM");
            data.PrintCollection(portsVesselsMI);
            Console.WriteLine($"Количество Yellow Sea: {ys}");
            Console.WriteLine($"Количество Bohai Sea: {bs}");
            Console.WriteLine($"Количество портов страны China, у которых Arrivals меньше среднего значения {sumA/lines.Length} по этому показателю в других  странах: {ch}");
        }

        /// <summary>
        /// Выводит на экран переупорядоченный набор данных, где данные упорядочены в алфавитном порядке по полю Port Name.
        /// Сохраняет в файл, название которому вводит пользователь
        /// </summary>
        /// <param name="menuItem">пункт меню 5</param>
        /// <param name="menu">меню</param>
        private static void SortPort_Name(MenuItem menuItem, Menu menu)
        {
            string[] lines = Operations_with_CSV.ReadFileCSV(fileName);
            if (lines is null)
            {
                return;
            }
            Screen_field data = new(lines);
            List<string> sorted_Lines = [",Country,Port Name,UN Code,Vessels in Port,Departures(Last 24 Hours),Arrivals(Last 24 Hours),Expected Arrivals,Type,Area Local,Area Global,Also known as"];
            data.Ports.Sort(new PortNameComp());
            List<Port> sortedPorts = [];
            int k = 0;
            foreach (Port pr in data.Ports)
            {
                if (pr.Type == "Port")
                {

                    sortedPorts.Add(pr);
                    sorted_Lines.Add($"{k},{Operations_with_CSV.ConvertToString(pr)}");
                    k++;
                }
            }
            data.PrintCollection(sortedPorts);

            Console.Write("Введите название для файла, куда будут записаны данные (без .csv): ");
            string title;
            bool flag;
            do
            {
                title = Console.ReadLine();
                flag = Operations_with_CSV.RightName(title);

            } while (!flag);

            File.WriteAllLines($"../../../../WorkingFiles/{title}.csv", sorted_Lines);
            Console.WriteLine($"Данные записаны в файл {title}.csv");

        }

        /// <summary>
        /// Выводить на экран выборку портов, Departures которых не более, чем на 10 единиц
        /// меньше максимального значения Departures среди всех портов. Сохраняет данные в файл Departures-Port.csv
        /// </summary>
        /// <param name="menuItem">пункт меню 6</param>
        /// <param name="menu">меню</param>
        private static void SpecialChooseDep(MenuItem menuItem, Menu menu)
        {
            int maxDep = 0;
            string[] lines = Operations_with_CSV.ReadFileCSV(fileName);
            if (lines is null)
            {
                return;
            }
            List<string> newDeps = [",Country,Port Name,UN Code,Vessels in Port,Departures(Last 24 Hours),Arrivals(Last 24 Hours),Expected Arrivals,Type,Area Local,Area Global,Also known as"];
            int k = 0;
            Screen_field data = new(lines);
            List<Port> portsDep = [];
            foreach (Port pr in data.Ports)
            {
                maxDep = Math.Max(pr.Departures, maxDep);
            }
            Console.WriteLine(maxDep);
            foreach (Port pr in data.Ports)
            {
                if ((maxDep - pr.Departures) <= 10)
                {
                    portsDep.Add(pr);
                    newDeps.Add($"{k},{Operations_with_CSV.ConvertToString(pr)}");
                    k++;
                }
            }
            data.PrintCollection(portsDep);
            File.WriteAllLines($"../../../../WorkingFiles/Departures-Port.csv", newDeps);
            Console.WriteLine($"Данные записаны в файл Departures-Port.csv");
        }

        /// <summary>
        /// Завершает работу консольного приложения
        /// </summary>
        /// <param name="menuItem">пункт меню 7</param>
        /// <param name="menu">меню</param>
        private static void Exit(MenuItem menuItem, Menu menu)
        {
            Environment.Exit(0);
        }
    }
}