﻿using System;

namespace ProjectHSE_2
{
    /// <summary>
    /// Обеспечивает логику сравнения для сортировки объектов Port по полю Port_Name
    /// </summary>
    public class PortNameComp : IComparer<Port>
    {
        /// <summary>
        /// Единственный метод класса сравнивающий объекты типа Port по полю Port_Name.
        /// </summary>
        /// <param name="e1">Первый объект</param>
        /// <param name="e2">Второй объект</param>
        /// <returns>Целое число со знаком, указывающее относительное значение объектов Port по полю Port_Name</returns>
        public int Compare(Port e1, Port e2)
        {
            return string.Compare(e1.Port_Name, e2.Port_Name);
        }
    }
}