﻿using System;

namespace ProjectHSE_2
{
    /// <summary>
    /// Класс кастомизируемой выдачи данных в консоль
    /// </summary>
    internal class Screen_field
    {
        public List<Port> Ports = [];

        public string[] Fields = [
            "Country",
        "Port_Name",
        "UN_Code",
        "Vessels_in_Port",
        "Departures",
        "Arrivals",
        "Expected_Arrivals",
        "Type",
        "Area_Local",
        "Area_Global",
        "Also_Known_As"
                ];

        /// <summary>
        /// метод конструктора принимает список строк файла и в цикле конвертирует в список объектов (без строки заголовков)
        /// </summary>
        /// <param name="strings">список строк из файла</param>
        public Screen_field(string[] strings)
        {
            for (int i = 1; i < strings.Length; i++)
            {
                AddString(strings[i]);
            }
        }

        /// <summary>
        /// добавляет строку, конвертированную в тип Port методом другого класса, в список объектов
        /// </summary>
        /// <param name="str">строка файла</param>
        public void AddString(string str)
        {
            Ports.Add(Operations_with_CSV.PortsConvertToString(str));
        }

        /// <summary>
        /// Выводит на экран переданные данные в виде списка
        /// </summary>
        /// <param name="elems">список данных типа Port</param>
        public void PrintCollection(List<Port> elems)
        {
            DrawTable(elems);
        }


        /// <summary>
        /// Метод для отрисовки данных на экране в виде таблицы
        /// </summary>
        /// <param name="prts">Список данных типа Port</param>
        private void DrawTable(List<Port> prts)
        {
            string horizontalLine = new('-', 150);
            string verticalLines = "|{0,3}|{1,20}|{2,12}|{3,3}|{4,3}|{5,3}|{6,3}|{7,3}|{8,4}|{9,15}|{10,15}|{11,3}|"; // шапка таблицы
            Console.WriteLine(horizontalLine);
            Console.WriteLine(verticalLines, "#", "Country", "Port_Name", "UN", "Vessels", "Dep", "Arr", "ExpArr", "Type", "AreaLoc", "AreaGlob", "Known_As"); //сокращённые названия столбцов. чтобы влезли в экран
            Console.WriteLine(horizontalLine);
            for (int i = 0; i < prts.Count; i++)
            {
                Console.WriteLine(verticalLines,
                    i,
                    prts[i].Country,
                    prts[i].Port_Name,
                    prts[i].UN_Code,
                    prts[i].Vessels_in_Port,
                    prts[i].Departures,
                    prts[i].Arrivals,
                    prts[i].Expected_Arrivals,
                    prts[i].Type,
                    prts[i].Area_Local,
                    prts[i].Area_Global,
                    prts[i].Also_Known_As);
            }
            Console.WriteLine(horizontalLine);
        }
    }
}
