﻿using System;

namespace ProjectHSE_2
{
    /// <summary>
    /// Класс для создания меню
    /// </summary>
    /// <param name="title">Заголовок меню</param>
    /// <param name="items">Названия элементов меню</param>
    internal class Menu(string title, MenuItem[] items)
    {
        public MenuItem[] Items = items;
        public string Title = title;

        /// <summary>
        /// Отрисовка меню на экране
        /// </summary>
        private void DrawMenu()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("-----------------");
            Console.WriteLine(Title + "\n");
            for (int i = 0; i < Items.Length; i++)
            {
                Console.WriteLine(Items[i].Name);
            }
            Console.WriteLine("_________________\n");
            Console.ResetColor();
        }

        /// <summary>
        /// Запускает меню
        /// </summary>
        public void Run()
        {
            DrawMenu();
            while (true)
            {
                ConsoleKey key = Console.ReadKey(true).Key;
                if (key == ConsoleKey.D7)
                {
                    break;
                }
                for (int i = 0; i < Items.Length; i++)
                {
                    if (Items[i].Key == key)
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine($"Вы выбрали: {Items[i].Name}");
                        Console.WriteLine("_________________\n");
                        Console.ResetColor();

                        Items[i].Action(Items[i], this);
                        DrawMenu();
                    }
                }
            }
        }
    }

    // Объявление делегата для удобного названия методов потом
    internal delegate void ActionOfMenuItem(MenuItem item, Menu menu);

    /// <summary>
    /// Класс для объектов меню
    /// </summary>
    internal class MenuItem(ConsoleKey key, string name, ActionOfMenuItem action)
    {
        public ConsoleKey Key { get; } = key;
        public string Name { get; } = name;
        public ActionOfMenuItem Action { get; } = action;
    }
}


