﻿using System;

namespace ProjectHSE_2
{
    /// <summary>
    /// Класс для работы с файлами .csv формата
    /// </summary>
    public static class Operations_with_CSV
    {
        /// <summary>
        /// Метод для считывания файла с отработкой всех исключений
        /// </summary>
        /// <param name="fileName">Название файла</param>
        /// <returns>возвращает данные в виде списка</returns>
        static public string[] ReadFileCSV(string fileName)
        {

            string[] lines = null;

            try
            {
                lines = File.ReadAllLines($"../../../../WorkingFiles/{fileName}");
            }
            catch (ArgumentException)
            {
                Console.WriteLine($"Ошибка! Проверьте введённые данные и попробуйте ещё раз");
                return lines;
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine($"Ошибка! Файл не найден. Проверьте введённые данные и попробуйте ещё раз");
                return lines;
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine($"Ошибка! Директория не найдена. Проверьте введённые данные и попробуйте ещё раз");
                return lines;
            }
            catch (IOException)
            {
                Console.WriteLine($"Ошибка! Не удалось открыть файл. Проверьте введённые данные и попробуйте ещё раз");
                return lines;
            }

            return lines;
        }

        /// <summary>
        /// Метод для проверки корректности введённого названия для файла
        /// </summary>
        /// <param name="name">введённое пользователем название файла</param>
        /// <returns>возвращает Истину если всё нормально и Ложь если есть ошибки</returns>
        public static bool RightName(string name)
        {
            char[] incorrectSymbols = Path.GetInvalidFileNameChars();
            if (name.IndexOfAny(incorrectSymbols) != -1)
            {
                Console.WriteLine("Ошибка! Имя файла содержит недопустимые символы.");
                return false;
            }
            else
            {
                try
                {
                    File.WriteAllLines($"../../../../WorkingFiles/{name}.csv", [","]);
                }
                catch (ArgumentNullException)
                {
                    Console.WriteLine($"Ошибка! Введено некорректное название");
                    return false;
                }
                catch (ArgumentException)
                {
                    Console.WriteLine($"Ошибка! Проверьте введённое название и попробуйте ещё раз");
                    return false;
                }
                catch (PathTooLongException)
                {
                    Console.WriteLine($"Ошибка! Проверьте введённое название и попробуйте ещё раз");
                    return false;
                }
                catch (DirectoryNotFoundException)
                {
                    Console.WriteLine($"Ошибка! Директория не найдена. Проверьте введённые данные и попробуйте ещё раз");
                    return false;
                }
                catch (IOException)
                {
                    Console.WriteLine($"Ошибка! Не удалось открыть файл. Проверьте введённые данные и попробуйте ещё раз");
                    return false;
                }
                catch (UnauthorizedAccessException)
                {
                    Console.WriteLine($"Ошибка! Проверьте введённые данные и попробуйте ещё раз");
                    return false;
                }
            }
            return true;
        }

         /// <summary>
         /// Конвертирует строку из файла в объект типа Port
         /// </summary>
         /// <param name="str">строка csv файла</param>
         /// <returns>возвращает объект типа Port</returns>
         static public Port PortsConvertToString(string str)
         {
            Port ports = new();
            str = DeleteQuotes(str);
            string[] values = str.Split(',');
            try
            {
                ports.Country = values[1];
                ports.Port_Name = values[2];
                ports.UN_Code = values[3];
                ports.Vessels_in_Port = Convert.ToInt16(values[4]);
                ports.Departures = Convert.ToInt16(values[5]);
                ports.Arrivals = Convert.ToInt16(values[6]);
                ports.Expected_Arrivals = Convert.ToInt16(values[7]);
                ports.Type = values[8];
                ports.Area_Local = values[9];
                ports.Area_Global = values[10];
                ports.Also_Known_As = values[11];
            }
            catch (IOException)
            {
                Console.WriteLine($"Ошибка конвертации строки в объект");
                ports = null;
            }
            return ports;
         }

        /// <summary>
        /// Метод для возвращения строк файла к виду, в котором они были записаны (в частности случай с кавычками)
        /// </summary>
        /// <param name="str">строка данных</param>
        /// <returns>правильно отформатированная и оформленная строка</returns>
        static public string ConvertToString(Port str)
        {
            string[] line = [str.Country, str.Port_Name, str.UN_Code, str.Vessels_in_Port.ToString(), str.Departures.ToString(), str.Arrivals.ToString(), str.Expected_Arrivals.ToString(), str.Type, str.Area_Local, str.Area_Global, str.Also_Known_As];
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i].Contains(';'))
                {
                    line[i] = "\"" + line[i].Replace(";", ",") + "\"";
                }
            }
            return string.Join(",", line);
        }

        /// <summary>
        /// Метод для выборки всех использованных данных определённого поля (в частности страна порта)
        /// </summary>
        /// <param name="fileName">Название файла, откуда надо сделать выборку полей</param>
        /// <param name="Field">Название поля по которому надо сделать выборку</param>
        /// <returns>список (строчный) неповторяющихся использованных данных</returns>
        static public string[] CountField(string fileName, string Field)
        {
            List<string> fields = [];


            string[] lines;
            try
            {
                lines = File.ReadAllLines($"../../../../WorkingFiles/{fileName}");
            }
            catch (ArgumentException)
            {
                Console.WriteLine($"Ошибка! Проверьте введённые данные и попробуйте ещё раз");
                return [.. fields];
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine($"Ошибка! Файл не найден. Проверьте введённые данные и попробуйте ещё раз");
                return [.. fields];
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine($"Ошибка! Директория не найдена. Проверьте введённые данные и попробуйте ещё раз");
                return [.. fields];
            }
            catch (IOException)
            {
                Console.WriteLine($"Ошибка! Не удалось открыть файл. Проверьте введённые данные и попробуйте ещё раз");
                return [.. fields];
            }
            int num = 0;
            string[] str1 = lines[0].Split(',');
            for (int i = 0; i < str1.Length; i++)
            {
                if (str1[i].ToString() == Field)
                {
                    num = i; break;
                }
            }
            if (num == 0)
            {
                Console.WriteLine("Ошибка");
                return [.. fields];
            }
            for (int i = 1; i < lines.Length; i++)
            {
                string str = DeleteQuotes(lines[i]);
                string[] line = str.Split(',');
                if (!fields.Contains(line[num]))
                {
                    fields.Add(line[num]);
                }
            }
            return [.. fields];
        }

        /// <summary>
        /// Метод, делающий файл после прочтения возможным для корректного разделения (удаляющий кавычки, запятые, мешающие делить)
        /// </summary>
        /// <param name="str">Строка файла</param>
        /// <returns>Удобная для деления строка файла</returns>
        static private string DeleteQuotes(string str)
        {
            int q2 = str.LastIndexOf('\"');
            int q1 = q2 > 0 ? str.LastIndexOf('\"', q2 - 1) : -1;
            if (q2 == -1 || q1 == -1)
            {
                return str;
            }
            else
            {
                int count = str.Split('\"').Length - 1;
                for (int i = 0; i < count; i += 2)
                {
                    try
                    {
                        q2 = str.LastIndexOf('\"');
                        q1 = str.LastIndexOf('\"', q2 - 1);
                        string oldSubString = str.Substring(q1 + 1, q2 - q1 - 1);
                        string newSubString = oldSubString.Replace(",", ";");
                        str = str.Replace('\"' + oldSubString + '\"', newSubString);
                    }
                    catch (ArgumentOutOfRangeException) //Если в кавычках были одинаковые данные
                    {
                        break;
                    }
                }
                return str;
            }
        }
    }
}

